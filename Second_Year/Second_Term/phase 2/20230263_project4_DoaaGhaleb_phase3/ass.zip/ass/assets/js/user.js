// User JavaScript file for JobSearch Website

// DOM Content Loaded Event Listener
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const user = getCurrentUser();
    
    // Initialize search jobs page if on that page
    if (window.location.pathname.includes('search_jobs.html')) {
        initSearchJobs();
        initModal('job-details-modal');
    }
    
    // Initialize applied jobs page if on that page
    if (window.location.pathname.includes('applied_jobs.html')) {
        if (!user) {
            window.location.href = '/login.html?redirect=' + encodeURIComponent(window.location.pathname);
            return;
        }
        initAppliedJobs();
        initModal('application-details-modal');
    }
});

// Initialize the job search page
function initSearchJobs() {
    // Load all available jobs
    loadAvailableJobs();
    
    // Load companies for filter
    loadCompaniesFilter();
    
    // Setup search and filter functionality
    setupSearchFilters();
}

// Load all open jobs
async function loadAvailableJobs() {
    const jobsContainer = document.getElementById('search-results-container');
    const noResultsMessage = document.getElementById('no-results-message');
    const resultsCount = document.getElementById('results-count');
    if (!jobsContainer) return;
    // Fetch jobs from backend
    const allJobs = await getJobs();
    const openJobs = allJobs.filter(job => job.status === 'Open');
    if (openJobs.length === 0) {
        if (noResultsMessage) noResultsMessage.style.display = 'block';
        if (resultsCount) resultsCount.textContent = '0 jobs found';
        return;
    }
    if (resultsCount) resultsCount.textContent = `${openJobs.length} jobs found`;
    jobsContainer.innerHTML = '';
    // Fetch applications for current user
    const user = getCurrentUser();
    const applications = user ? (await getApplications()).filter(app => app.user === user.id) : [];
    const appliedJobIds = applications.map(app => app.job);
    openJobs.forEach(job => {
        job.applied = appliedJobIds.includes(job.id);
        const jobCard = createJobCard(job);
        jobsContainer.appendChild(jobCard);
    });
}

// Load companies for the company filter dropdown
async function loadCompaniesFilter() {
    const companyFilter = document.getElementById('company-filter');
    if (!companyFilter) return;
    const allJobs = await getJobs();
    const companies = [...new Set(allJobs.map(job => job.company))];
    while (companyFilter.options.length > 1) {
        companyFilter.remove(1);
    }
    companies.forEach(company => {
        const option = document.createElement('option');
        option.value = company;
        option.textContent = company;
        companyFilter.appendChild(option);
    });
}

// Setup job search and filter functionality
function setupSearchFilters() {
    const jobKeyword = document.getElementById('job-keyword');
    const experienceFilter = document.getElementById('experience-filter');
    const companyFilter = document.getElementById('company-filter');
    const searchButton = document.getElementById('search-button');
    
    // Apply filters when search button is clicked
    if (searchButton) {
        searchButton.addEventListener('click', applyJobFilters);
    }
    
    // Apply filters when Enter key is pressed in the search box
    if (jobKeyword) {
        jobKeyword.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                applyJobFilters();
            }
        });
    }
}

// Apply filters to job listings
async function applyJobFilters() {
    const jobKeyword = document.getElementById('job-keyword');
    const experienceFilter = document.getElementById('experience-filter');
    const companyFilter = document.getElementById('company-filter');
    const keyword = jobKeyword ? jobKeyword.value.toLowerCase() : '';
    const experience = experienceFilter ? experienceFilter.value : '';
    const company = companyFilter ? companyFilter.value : '';
    const allJobs = await getJobs();
    let filteredJobs = allJobs.filter(job => job.status === 'Open');
    if (keyword) {
        filteredJobs = filteredJobs.filter(job => job.title.toLowerCase().includes(keyword) || job.description.toLowerCase().includes(keyword));
    }
    if (experience) {
        const minExperience = parseInt(experience, 10);
        filteredJobs = filteredJobs.filter(job => job.experience >= minExperience);
    }
    if (company) {
        filteredJobs = filteredJobs.filter(job => job.company === company);
    }
    const jobsContainer = document.getElementById('search-results-container');
    const noResultsMessage = document.getElementById('no-results-message');
    const resultsCount = document.getElementById('results-count');
    if (!jobsContainer) return;
    jobsContainer.innerHTML = '';
    if (resultsCount) resultsCount.textContent = `${filteredJobs.length} jobs found`;
    if (filteredJobs.length === 0) {
        if (noResultsMessage) noResultsMessage.style.display = 'block';
        return;
    } else {
        if (noResultsMessage) noResultsMessage.style.display = 'none';
    }
    const user = getCurrentUser();
    const applications = user ? (await getApplications()).filter(app => app.user === user.id) : [];
    const appliedJobIds = applications.map(app => app.job);
    filteredJobs.forEach(job => {
        job.applied = appliedJobIds.includes(job.id);
        const jobCard = createJobCard(job);
        jobsContainer.appendChild(jobCard);
    });
}

// Create a DOM element for a job card
function createJobCard(job) {
    const user = getCurrentUser();
    
    const card = document.createElement('div');
    card.className = 'job-card';
    card.dataset.jobId = job.id;
    
    const headerDiv = document.createElement('div');
    headerDiv.className = 'job-card-header';
    
    const title = document.createElement('h3');
    title.className = 'job-title';
    title.textContent = job.title;
    
    const salary = document.createElement('span');
    salary.className = 'job-salary';
    salary.textContent = job.salary;
    
    headerDiv.appendChild(title);
    headerDiv.appendChild(salary);
    
    const bodyDiv = document.createElement('div');
    bodyDiv.className = 'job-card-body';
    
    const company = document.createElement('p');
    company.className = 'company-name';
    company.textContent = job.company;
    
    const experience = document.createElement('p');
    experience.className = 'job-experience';
    experience.textContent = `Experience: ${job.experience} years`;
    
    const description = document.createElement('p');
    description.className = 'job-description-preview';
    description.textContent = truncateText(job.description, 100);
    
    bodyDiv.appendChild(company);
    bodyDiv.appendChild(experience);
    bodyDiv.appendChild(description);
    
    const footerDiv = document.createElement('div');
    footerDiv.className = 'job-card-footer';
    
    const viewBtn = document.createElement('button');
    viewBtn.className = 'btn-view-details';
    viewBtn.textContent = 'View Details';
    viewBtn.onclick = function() {
        window.location.href = `job_details.html?id=${job.id}`;
    };
    
    footerDiv.appendChild(viewBtn);
    
    card.appendChild(headerDiv);
    card.appendChild(bodyDiv);
    card.appendChild(footerDiv);
    
    return card;
}

// Show job details in modal (fetch from backend)
async function viewJobDetails(jobId) {
    const modal = document.getElementById('job-details-modal');
    const detailsContainer = document.getElementById('job-details-container');
    const applyBtn = document.getElementById('apply-job-btn');
    if (!modal || !detailsContainer) return;
    // Fetch job details from backend
    const jobs = await getJobs();
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;
    detailsContainer.innerHTML = `
        <div class="job-details-header">
            <h2>${job.title}</h2>
            <span class="job-details-salary">${job.salary}</span>
        </div>
        <p class="job-details-company">
            <strong>Company:</strong> ${job.company}
        </p>
        <div class="job-details-info">
            <span><strong>Experience Required:</strong> ${job.experience} years</span>
            <span><strong>Posted:</strong> ${formatDate(job.created_at || job.createdAt)}</span>
        </div>
        <h3>Job Description:</h3>
        <div class="job-details-description">
            ${job.description.replace(/\n/g, '<br>')}
        </div>
    `;
    if (applyBtn) {
        const user = getCurrentUser();
        const applications = user ? (await getApplications()).filter(app => app.user === user.id) : [];
        const hasApplied = applications.some(app => app.job === jobId);
        if (!user || user.role !== 'user') {
            applyBtn.style.display = 'none';
        } else {
            applyBtn.style.display = 'inline-block';
            if (hasApplied) {
                applyBtn.textContent = 'Already Applied';
                applyBtn.disabled = true;
            } else {
                applyBtn.textContent = 'Apply Now';
                applyBtn.disabled = false;
                applyBtn.onclick = function() {
                    applyToJob(jobId);
                    modal.style.display = 'none';
                };
            }
        }
    }
    modal.style.display = 'block';
}

// Apply to a job using backend
async function applyToJob(jobId) {
    const user = getCurrentUser();
    if (!user) {
        window.location.href = '/login.html?redirect=' + encodeURIComponent(window.location.pathname);
        return;
    }
    if (user.role !== 'user') {
        alert('Only job seekers can apply to jobs');
        return;
    }
    // Check if already applied
    const applications = await getApplications();
    if (applications.some(app => app.job === jobId && app.user === user.id)) {
        alert('You have already applied to this job');
        return;
    }
    // Create new application via backend
    const res = await fetch('http://localhost:8000/api/applications/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ job: jobId })
    });
    if (res.ok) {
        alert('Successfully applied to this job');
        if (window.location.pathname.includes('search_jobs.html')) {
            loadAvailableJobs();
        }
    } else {
        alert('Failed to apply. Please try again.');
    }
}

// Initialize the applied jobs page
function initAppliedJobs() {
    const user = getCurrentUser();
    
    if (!user) return;
    
    // Load user's applications
    loadUserApplications();
    
    // Setup filtering
    setupApplicationFiltering();
}

// Load all applications for the current user from backend
async function loadUserApplications() {
    const user = getCurrentUser();
    const applicationsContainer = document.getElementById('applications-container');
    const noApplicationsMessage = document.getElementById('no-applications-message');
    if (!applicationsContainer || !user) return;
    // Fetch applications from backend
    const applications = (await getApplications()).filter(app => app.user === user.id);
    if (applications.length === 0) {
        if (noApplicationsMessage) noApplicationsMessage.style.display = 'block';
        return;
    }
    applicationsContainer.innerHTML = '';
    applications.forEach(application => {
        const applicationCard = createApplicationCard(application);
        applicationsContainer.appendChild(applicationCard);
    });
}

// Create a DOM element for an application card (backend fields)
function createApplicationCard(application) {
    const card = document.createElement('div');
    card.className = 'application-card';
    card.dataset.applicationId = application.id;
    const infoDiv = document.createElement('div');
    infoDiv.className = 'application-info';
    const title = document.createElement('h3');
    title.className = 'application-title';
    title.textContent = application.job_title || 'Job';
    const company = document.createElement('p');
    company.className = 'application-company';
    company.textContent = application.company || '';
    const date = document.createElement('p');
    date.className = 'application-date';
    date.textContent = `Applied on: ${formatDate(application.applied_at || application.appliedAt)}`;
    infoDiv.appendChild(title);
    infoDiv.appendChild(company);
    infoDiv.appendChild(date);
    const statusSpan = document.createElement('span');
    statusSpan.className = `application-status status-${application.status}`;
    statusSpan.textContent = capitalizeFirstLetter(application.status);
    card.appendChild(infoDiv);
    card.appendChild(statusSpan);
    card.addEventListener('click', function() {
        viewApplicationDetails(application.id);
    });
    return card;
}

// Setup application filtering
function setupApplicationFiltering() {
    const statusFilter = document.getElementById('application-status-filter');
    const searchInput = document.getElementById('applications-search');
    
    if (statusFilter) {
        statusFilter.addEventListener('change', applyApplicationFilters);
    }
    
    if (searchInput) {
        searchInput.addEventListener('input', applyApplicationFilters);
    }
}

// Apply filters to applications (async, backend)
async function applyApplicationFilters() {
    const user = getCurrentUser();
    if (!user) return;
    const statusFilter = document.getElementById('application-status-filter');
    const searchInput = document.getElementById('applications-search');
    const status = statusFilter ? statusFilter.value : 'all';
    const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
    // Fetch all applications for this user from backend
    let applications = (await getApplications()).filter(app => app.user === user.id);
    if (status !== 'all') {
        applications = applications.filter(app => app.status === status);
    }
    if (searchTerm) {
        // Optionally fetch job info for each application if needed
        applications = applications.filter(app => {
            // If jobTitle/company not present, skip search filter
            if (!app.job_title && !app.company) return true;
            return (app.job_title && app.job_title.toLowerCase().includes(searchTerm)) ||
                   (app.company && app.company.toLowerCase().includes(searchTerm));
        });
    }
    const applicationsContainer = document.getElementById('applications-container');
    const noApplicationsMessage = document.getElementById('no-applications-message');
    if (!applicationsContainer) return;
    applicationsContainer.innerHTML = '';
    if (applications.length === 0) {
        if (noApplicationsMessage) noApplicationsMessage.style.display = 'block';
        return;
    } else {
        if (noApplicationsMessage) noApplicationsMessage.style.display = 'none';
    }
    applications.forEach(application => {
        const applicationCard = createApplicationCard(application);
        applicationsContainer.appendChild(applicationCard);
    });
}

// View application details in modal (fetch job/application from backend)
async function viewApplicationDetails(applicationId) {
    const modal = document.getElementById('application-details-modal');
    const detailsContainer = document.getElementById('application-details-container');
    const withdrawBtn = document.getElementById('withdraw-application-btn');
    if (!modal || !detailsContainer) return;
    // Fetch application details from backend
    const applications = await getApplications();
    const application = applications.find(a => a.id === applicationId);
    if (!application) return;
    // Fetch job details from backend
    const jobs = await getJobs();
    const job = jobs.find(j => j.id === application.job);
    detailsContainer.innerHTML = `
        <div class="application-details-header">
            <h2>${job ? job.title : ''}</h2>
            <p>${job ? job.company : ''}</p>
        </div>
        <div class="application-details-status">
            <strong>Status:</strong> <span class="status-${application.status}">${capitalizeFirstLetter(application.status)}</span>
        </div>
        <p><strong>Applied on:</strong> ${formatDate(application.applied_at || application.appliedAt)}</p>
        <h3>Job Details:</h3>
        ${job ? 
            `<p><strong>Experience Required:</strong> ${job.experience} years</p>
             <p><strong>Salary:</strong> ${job.salary}</p>
             <div class="job-details-description">
                ${job.description.replace(/\n/g, '<br>')}
             </div>` 
            : 
            '<p>Original job listing is no longer available.</p>'
        }
    `;
    if (withdrawBtn) {
        withdrawBtn.onclick = async function() {
            if (confirm('Are you sure you want to withdraw this application?')) {
                await withdrawApplication(applicationId);
                modal.style.display = 'none';
            }
        };
    }
    modal.style.display = 'block';
}

// Withdraw an application using backend
async function withdrawApplication(applicationId) {
    await fetch(`http://127.0.0.1:8000/api/applications/${applicationId}/`, {
        method: 'DELETE',
        credentials: 'include'
    });
    loadUserApplications();
}

// Capitalize first letter of a string
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}